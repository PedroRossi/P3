package br.ufpe.cin.if710.p3.adapters

import android.support.v7.recyclerview.extensions.ListAdapter
import android.support.v7.util.DiffUtil
import android.view.LayoutInflater
import android.view.ViewGroup
import br.ufpe.cin.if710.p3.R
import br.ufpe.cin.if710.p3.database.models.Insight
import br.ufpe.cin.if710.p3.views.HistoryItemViewHolder

class InsightItemsAdapter(private val inflater: LayoutInflater) :
    ListAdapter<Insight, HistoryItemViewHolder>(ItemDiffer) {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): HistoryItemViewHolder {
        return HistoryItemViewHolder(inflater.inflate(R.layout.item, parent, false))
    }

    override fun onBindViewHolder(holder: HistoryItemViewHolder, position: Int) {
        holder.bindTo(getItem(position))
    }

    private object ItemDiffer : DiffUtil.ItemCallback<Insight>() {
        override fun areItemsTheSame(p0: Insight, p1: Insight): Boolean {
            return p0.title == p1.title
        }

        override fun areContentsTheSame(p0: Insight, p1: Insight): Boolean {
            return p0.description == p1.description
        }
    }
}