package br.ufpe.cin.if710.p3.database.models

interface Item {
    val title: String
    val description: String
}