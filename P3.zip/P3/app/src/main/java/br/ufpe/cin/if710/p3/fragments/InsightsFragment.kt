package br.ufpe.cin.if710.p3.fragments

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import br.ufpe.cin.if710.p3.R
import br.ufpe.cin.if710.p3.adapters.InsightItemsAdapter
import br.ufpe.cin.if710.p3.database.models.Insight
import br.ufpe.cin.if710.p3.utils.DB

class InsightsFragment  : Fragment() {

    private var insights: RecyclerView? = null

    companion object {
        fun newInstance() = InsightsFragment()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.insights, container, false)
        insights = view.findViewById(R.id.insights_items)
        val db = DB.getDatabase(this.context!!, "p3")
        val dao = db.insightDao()
        dao.insert(Insight(1, "Um Rango Legal", "3x ao dia"))
        val items = dao.getAll()
        insights?.apply {
            layoutManager = LinearLayoutManager(super.getContext())
            addItemDecoration(
                DividerItemDecoration(super.getContext(), DividerItemDecoration.VERTICAL)
            )
            addItemDecoration(
                DividerItemDecoration(super.getContext(), DividerItemDecoration.HORIZONTAL)
            )
            adapter = InsightItemsAdapter(layoutInflater).apply {
                submitList(items)
            }
        }
        return view
    }
}