package br.ufpe.cin.if710.p3.utils

import android.content.Context
import androidx.room.Room
import br.ufpe.cin.if710.p3.database.AppDatabase

class DB {
    companion object {
        fun getDatabase(context: Context, dbName: String): AppDatabase {
            val db = Room.databaseBuilder(context,AppDatabase::class.java, "dbName")
                .build()
            return db
        }
    }
}